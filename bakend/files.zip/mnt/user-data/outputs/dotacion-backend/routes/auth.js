import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import supabase from '../config/supabase.js'
import 'dotenv/config'

const router = Router()

// POST /api/auth/login
// Body: { nombre, clave, dependencia_id }
// El coordinador entra con su nombre, la clave general y su dependencia
router.post('/login', async (req, res) => {
  const { nombre, clave, dependencia_id } = req.body

  if (!nombre || !clave) {
    return res.status(400).json({ error: 'Nombre y clave son requeridos' })
  }

  // --- Login administrador ---
  if (clave === process.env.CLAVE_ADMIN) {
    const token = jwt.sign(
      { rol: 'admin', nombre: nombre || 'Administrador' },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    )
    return res.json({ token, rol: 'admin', nombre: nombre || 'Administrador' })
  }

  // --- Login coordinador ---
  if (clave !== process.env.CLAVE_COORDINADORES) {
    return res.status(401).json({ error: 'Clave incorrecta' })
  }

  if (!dependencia_id) {
    return res.status(400).json({ error: 'Selecciona tu dependencia' })
  }

  // Verificar que la dependencia exista
  const { data: dep, error: depError } = await supabase
    .from('dependencias')
    .select('id, nombre')
    .eq('id', dependencia_id)
    .single()

  if (depError || !dep) {
    return res.status(400).json({ error: 'Dependencia no encontrada' })
  }

  // Registrar o actualizar el coordinador en la tabla coordinadores
  // (la primera vez que entra queda registrado automáticamente)
  const { data: coord, error: coordError } = await supabase
    .from('coordinadores')
    .upsert(
      { nombre, dependencia_id, clave_hash: 'gestionada_por_env' },
      { onConflict: 'nombre,dependencia_id', ignoreDuplicates: false }
    )
    .select('id, nombre')
    .single()

  if (coordError) {
    return res.status(500).json({ error: 'Error registrando coordinador' })
  }

  const token = jwt.sign(
    {
      rol: 'coordinador',
      nombre: coord.nombre,
      coordinador_id: coord.id,
      dependencia_id
    },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  )

  return res.json({
    token,
    rol: 'coordinador',
    nombre: coord.nombre,
    coordinador_id: coord.id,
    dependencia_id,
    dependencia_nombre: dep.nombre
  })
})

// GET /api/auth/estado-formulario
// Cualquiera puede consultar si el formulario está abierto o cerrado
router.get('/estado-formulario', async (req, res) => {
  const { data, error } = await supabase
    .from('formulario_estado')
    .select('cerrado, cerrado_en, cerrado_por, abierto_en')
    .eq('id', 'global')
    .single()

  if (error) return res.status(500).json({ error: 'Error consultando estado' })
  return res.json(data)
})

export default router
